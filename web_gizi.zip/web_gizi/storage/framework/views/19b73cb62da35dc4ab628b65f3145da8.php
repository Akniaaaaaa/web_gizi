
<?php $__env->startSection('corosel'); ?>
<!-- ======= Hero Section ======= -->
<section id="hero" class="hero d-flex align-items-center">

    <div class="container">
        <div class="row">
            <div class="col-lg-6 d-flex flex-column justify-content-center">
                <h1 data-aos="fade-up">Periksa Gizimu</h1>
                <h2 data-aos="fade-up" data-aos-delay="400">lorem ipsum lorem ipsum lorem ipsum lorem ipsum</h2>
                <div data-aos="fade-up" data-aos-delay="600">
                    <div class="navbar mt-2 ml-5">

                        <!-- <a href="#about" class="btn-get-started scrollto d-inline-flex align-items-center justify-content-center align-self-center">
                                <span>Get Started</span>
                                <i class="bi bi-arrow-right"></i>
                            </a> -->
                        <?php if(Route::has('login')): ?>
                        <div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right z-10">
                            <?php if(auth()->guard()->check()): ?>
                            <!-- <a href="<?php echo e(url('/dashboard')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Dashboard</a> -->
                            <a class="getstarted scrollto" href="<?php echo e(route('check_gizi')); ?>">Periksa Sekarang</a>
                            <?php else: ?>
                            <!-- <a href="<?php echo e(route('login')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Log in</a> -->
                            <a class="getstarted scrollto" href="<?php echo e(route('login')); ?>">Masuk</a>

                            <?php if(Route::has('register')): ?>
                            <a class="getstarted scrollto" href="<?php echo e(route('register')); ?>">Get Started </a>
                            <!-- <a href="<?php echo e(route('register')); ?>" class="ml-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Register</a> -->
                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 hero-img" data-aos="zoom-out" data-aos-delay="200">
                <img src="<?php echo e(url('assets/assets/img/hero-img.png')); ?>" class="img-fluid" alt="">
            </div>
        </div>
    </div>

</section><!-- End Hero -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\web_gizi\web_gizi\resources\views/gizi/index.blade.php ENDPATH**/ ?>